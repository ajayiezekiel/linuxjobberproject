from setuptools import find_packages, setup


setup(
    name = 'ajayiezekiel9000',
    version = '0.1',
    packages = find_packages(),
    author = 'ajayiezekiel9000scrumy',
    author_email = 'ade@gmail.com',
)

