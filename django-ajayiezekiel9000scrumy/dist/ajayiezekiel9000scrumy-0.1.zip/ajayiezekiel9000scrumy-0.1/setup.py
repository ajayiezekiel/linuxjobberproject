from setuptools import find_packages, setup


setup(
    name = 'ajayiezekiel9000scrumy',
    version = '0.1',
    packages = find_packages(),
    author = 'Ezekiel Ajayi',
    author_email = 'ade@gmail.com',
)

