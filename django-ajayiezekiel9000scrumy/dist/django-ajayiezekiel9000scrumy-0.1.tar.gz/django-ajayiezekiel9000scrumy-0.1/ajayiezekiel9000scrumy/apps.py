from django.apps import AppConfig


class Ajayiezekiel9000ScrumyConfig(AppConfig):
    name = 'ajayiezekiel9000scrumy'
